import SwiftUI

@main
struct HAL_EAP_Registration_iOSApp: App {
    @StateObject private var store = OfflineStore()
    @StateObject private var sync = SyncService()
    @State private var showingSplash = true

    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                    .environmentObject(store)
                    .environmentObject(sync)
                    .opacity(showingSplash ? 0 : 1)

                if showingSplash {
                    SplashView()
                        .transition(.opacity)
                }
            }
            .task {
                try? await Task.sleep(nanoseconds: 2_300_000_000)
                withAnimation(.easeInOut(duration: 0.28)) {
                    showingSplash = false
                }
                if sync.isOnline && store.pendingCount > 0 {
                    await sync.syncAll(store: store)
                }
            }
        }
    }
}
