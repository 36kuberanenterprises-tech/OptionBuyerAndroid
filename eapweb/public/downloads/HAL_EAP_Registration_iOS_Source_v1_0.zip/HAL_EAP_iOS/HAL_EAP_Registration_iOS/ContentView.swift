import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: OfflineStore
    @EnvironmentObject var sync: SyncService

    var body: some View {
        TabView {
            RegistrationFormView()
                .tabItem { Label("Home", systemImage: "house.fill") }

            ApplicationsView()
                .tabItem { Label("Applications", systemImage: "list.bullet.rectangle") }

            MoreView()
                .tabItem { Label("More", systemImage: "ellipsis.circle") }
        }
        .tint(Color(red: 40/255, green: 153/255, blue: 50/255))
    }
}
