import Foundation
import Network

struct APIConfig {
    static let webAppURL = URL(string: "https://script.google.com/macros/s/AKfycbwE3zSkPHObRKJhtjQjz34m3gwFJ5fr0ptrb-YCyYZoV8fMDZZwKSnsiqCEgN7GFvrJxw/exec")!
    static let token = "EAP_HAL_EDII_2026_AJAY_SRO_8K4M7X2P"
}

@MainActor
final class SyncService: ObservableObject {
    @Published var isOnline = true
    @Published var isSyncing = false
    @Published var lastMessage = ""
    @Published var centralStatus = CentralStatus()

    private let monitor = NWPathMonitor()
    private let monitorQueue = DispatchQueue(label: "eap.network.monitor")

    init() {
        monitor.pathUpdateHandler = { [weak self] path in
            Task { @MainActor in
                self?.isOnline = path.status == .satisfied
            }
        }
        monitor.start(queue: monitorQueue)
    }

    deinit {
        monitor.cancel()
    }

    func refreshStatus(location: ProjectLocation?) async {
        guard isOnline else { return }
        var payload: [String: Any] = [
            "action": "getStatus",
            "projectLocation": location?.display ?? "",
            "locationCode": location?.code ?? "NA"
        ]
        payload["token"] = APIConfig.token

        do {
            let response = try await post(payload)
            guard response.success else { return }
            centralStatus = CentralStatus(
                totalApplicationCount: response.totalApplicationCount ?? 0,
                locationApplicationCount: response.locationApplicationCount ?? 0,
                nextTotalSerial: response.nextTotalSerial ?? "",
                nextLocationSerial: response.nextLocationSerial ?? ""
            )
        } catch {
            lastMessage = "Central status unavailable."
        }
    }

    func syncAll(store: OfflineStore) async {
        guard isOnline, !isSyncing else { return }
        isSyncing = true
        defer { isSyncing = false }

        let pending = store.pendingRecords()
        if pending.isEmpty {
            lastMessage = "No pending applications."
            return
        }

        var synced = 0
        for var record in pending {
            if !isOnline { break }
            record.status = .syncing
            store.update(record)

            do {
                if record.payload.totalSerialNumber.isEmpty || record.payload.individualSerialNumber.isEmpty {
                    let reserve = try await reserveSerial(for: record.payload)
                    guard reserve.success,
                          let total = reserve.totalSerialNumber,
                          let location = reserve.individualSerialNumber,
                          !total.isEmpty, !location.isEmpty else {
                        throw SyncError.server(reserve.message ?? "Unable to reserve central serial.")
                    }
                    record.payload.totalSerialNumber = total
                    record.payload.individualSerialNumber = location
                    record.payload.totalApplicationCount = reserve.totalApplicationCount ?? 0
                    record.payload.locationApplicationCount = reserve.locationApplicationCount ?? 0
                }

                if record.payload.pdfBase64.isEmpty {
                    let pdf = try PDFGenerator.generate(payload: record.payload)
                    record.payload.pdfFileName = pdf.fileName
                    record.payload.pdfBase64 = pdf.data.base64EncodedString()
                    record.payload.localPdfLocation = pdf.url.path
                }

                store.update(record)
                let submitted = try await submit(record.payload)
                guard submitted.success else {
                    throw SyncError.server(submitted.message ?? "Server rejected application.")
                }

                record.payload.pdfUrl = submitted.pdfUrl ?? ""
                record.payload.photoUrl = submitted.photoUrl ?? ""
                record.payload.signatureUrl = submitted.signatureUrl ?? ""
                record.payload.editableUrl = submitted.editableUrl ?? ""
                record.payload.folderUrl = submitted.folderUrl ?? ""
                record.payload.totalApplicationCount = submitted.totalApplicationCount ?? record.payload.totalApplicationCount
                record.payload.locationApplicationCount = submitted.locationApplicationCount ?? record.payload.locationApplicationCount
                record.status = .synced
                record.syncedAt = Date()
                record.lastError = nil
                store.update(record)
                synced += 1
            } catch {
                record.status = .pending
                record.lastError = error.localizedDescription
                store.update(record)
            }
        }

        lastMessage = synced > 0 ? "Synced \(synced) application(s) to EAP_Master Sheet." : "Pending applications are still waiting for sync."
    }

    private func reserveSerial(for payload: RegistrationPayload) async throws -> APIResponse {
        var request: [String: Any] = [
            "action": "reserveSerial",
            "clientRequestId": payload.clientRequestId,
            "projectLocation": payload.projectLocation,
            "locationCode": payload.locationCode,
            "name": payload.name,
            "token": APIConfig.token
        ]
        request["token"] = APIConfig.token
        return try await post(request)
    }

    private func submit(_ payload: RegistrationPayload) async throws -> APIResponse {
        let data = try JSONEncoder().encode(payload)
        var object = try JSONSerialization.jsonObject(with: data) as? [String: Any] ?? [:]
        object["action"] = "submitRegistration"
        object["token"] = APIConfig.token
        return try await post(object)
    }

    private func post(_ object: [String: Any]) async throws -> APIResponse {
        let jsonData = try JSONSerialization.data(withJSONObject: object)
        let jsonString = String(data: jsonData, encoding: .utf8) ?? "{}"

        var components = URLComponents()
        components.queryItems = [URLQueryItem(name: "payload", value: jsonString)]
        let body = components.percentEncodedQuery?.data(using: .utf8) ?? Data()

        var request = URLRequest(url: APIConfig.webAppURL)
        request.httpMethod = "POST"
        request.timeoutInterval = 45
        request.setValue("application/x-www-form-urlencoded; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        request.httpBody = body

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200...399).contains(http.statusCode) else {
            throw SyncError.network
        }
        return try JSONDecoder().decode(APIResponse.self, from: data)
    }
}

enum SyncError: LocalizedError {
    case network
    case server(String)

    var errorDescription: String? {
        switch self {
        case .network: return "Central server connection failed."
        case .server(let message): return message
        }
    }
}
