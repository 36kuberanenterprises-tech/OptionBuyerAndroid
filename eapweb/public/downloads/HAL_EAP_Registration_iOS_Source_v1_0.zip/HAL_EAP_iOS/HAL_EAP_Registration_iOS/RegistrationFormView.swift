import SwiftUI
import UIKit
import AVFoundation

struct RegistrationFormView: View {
    @EnvironmentObject var store: OfflineStore
    @EnvironmentObject var sync: SyncService

    @State private var eapDate = Date()
    @State private var selectedLocation: ProjectLocation?
    @State private var name = ""
    @State private var gender: Gender?
    @State private var dob = Calendar.current.date(byAdding: .year, value: -18, to: Date()) ?? Date()
    @State private var guardian = ""
    @State private var address = ""
    @State private var panchayat = ""
    @State private var pinCode = ""
    @State private var mobile = ""
    @State private var alternateMobile = ""
    @State private var email = ""
    @State private var aadhaar = ""
    @State private var education = ""
    @State private var occupation = ""
    @State private var income = ""
    @State private var category: Category?
    @State private var intention: Intention?
    @State private var sector: BusinessSector?
    @State private var msdpInterest: Bool?
    @State private var candidatePhoto: UIImage?
    @State private var signaturePhoto: UIImage?
    @State private var declaration = false

    @State private var showCandidateCamera = false
    @State private var showCandidateLibrary = false
    @State private var showSignatureCamera = false
    @State private var showSignatureLibrary = false
    @State private var showCameraUnavailable = false
    @State private var isSubmitting = false
    @State private var resultMessage = ""
    @State private var showResult = false

    private let green = Color(red: 40/255, green: 153/255, blue: 50/255)
    private let darkGreen = Color(red: 28/255, green: 125/255, blue: 39/255)

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {
                    title
                    sectionCard("Event Setup") { eventSection }
                    statusCards
                    sectionCard("Personal Details") { personalSection }
                    sectionCard("Location Details") { locationSection }
                    sectionCard("Contact Details") { contactSection }
                    sectionCard("Education & Employment Details") { educationSection }
                    sectionCard("EAP Details") { eapSection }
                    sectionCard("Documents") { documentsSection }
                    declarationSection
                    submitButton
                }
                .padding(.horizontal, 14)
                .padding(.bottom, 24)
            }
            .background(Color(.systemGroupedBackground))
            .toolbar(.hidden, for: .navigationBar)
            .task {
                await sync.refreshStatus(location: selectedLocation)
                if sync.isOnline && store.pendingCount > 0 {
                    await sync.syncAll(store: store)
                    await sync.refreshStatus(location: selectedLocation)
                }
            }
            .onChange(of: selectedLocation) { _, newValue in
                Task { await sync.refreshStatus(location: newValue) }
            }
            .sheet(isPresented: $showCandidateCamera) { CameraPicker(image: $candidatePhoto) }
            .sheet(isPresented: $showCandidateLibrary) { PhotoLibraryPicker(image: $candidatePhoto) }
            .sheet(isPresented: $showSignatureCamera) { CameraPicker(image: $signaturePhoto) }
            .sheet(isPresented: $showSignatureLibrary) { PhotoLibraryPicker(image: $signaturePhoto) }
            .alert("Camera", isPresented: $showCameraUnavailable) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Camera could not be opened. Please allow Camera permission in Settings or use Upload Photo.")
            }
            .alert("HAL EAP Registration", isPresented: $showResult) {
                Button("Next Applicant") { resetApplicantFields() }
                Button("OK", role: .cancel) {}
            } message: {
                Text(resultMessage)
            }
        }
    }

    private var title: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Image("EDII")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 44, height: 44)
                    .clipShape(Circle())
                VStack(alignment: .leading, spacing: 1) {
                    Text("EDII").font(.headline).foregroundStyle(.white)
                    Text("HAL EAP Registration").font(.subheadline.bold()).foregroundStyle(.white)
                }
                Spacer()
                Button {
                    Task {
                        await sync.syncAll(store: store)
                        await sync.refreshStatus(location: selectedLocation)
                    }
                } label: {
                    Image(systemName: "arrow.triangle.2.circlepath")
                        .font(.title3.bold())
                        .foregroundStyle(.white)
                        .padding(10)
                        .background(.white.opacity(0.14), in: Circle())
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(LinearGradient(colors: [darkGreen, green], startPoint: .leading, endPoint: .trailing))
            .clipShape(RoundedRectangle(cornerRadius: 18))

            Text("New EAP Registration")
                .font(.title2.bold())
                .padding(.top, 8)
        }
    }

    @ViewBuilder
    private func sectionCard<Content: View>(_ heading: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(heading)
                .font(.headline)
                .foregroundStyle(darkGreen)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(Color.green.opacity(0.08))
            content().padding(.horizontal, 14).padding(.bottom, 14)
        }
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.green.opacity(0.15)))
    }

    private var eventSection: some View {
        VStack(spacing: 12) {
            DatePicker("EAP Date *", selection: $eapDate, displayedComponents: .date)
            Picker("HAL Project Location *", selection: $selectedLocation) {
                Text("Select").tag(ProjectLocation?.none)
                ForEach(ProjectLocation.all) { loc in
                    Text(loc.display).tag(ProjectLocation?.some(loc))
                }
            }
            .pickerStyle(.menu)
        }
    }

    private var statusCards: some View {
        VStack(spacing: 10) {
            statusCard(
                heading: "TOTAL APPLICATIONS",
                count: sync.isOnline ? String(sync.centralStatus.totalApplicationCount) : "—",
                line1: "Pending on this phone: \(store.pendingCount)",
                line2: sync.isOnline && !sync.centralStatus.nextTotalSerial.isEmpty
                    ? "Next: \(sync.centralStatus.nextTotalSerial)"
                    : "Connect to update central total"
            )
            statusCard(
                heading: "LOCATION APPLICATIONS",
                count: selectedLocation == nil ? "—" : (sync.isOnline ? String(sync.centralStatus.locationApplicationCount) : "—"),
                line1: selectedLocation?.place ?? "Select HAL Project Location",
                line2: sync.isOnline && !sync.centralStatus.nextLocationSerial.isEmpty
                    ? "Next: \(sync.centralStatus.nextLocationSerial)"
                    : "Serial assigned centrally during sync"
            )
        }
    }

    private func statusCard(heading: String, count: String, line1: String, line2: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(heading).font(.caption.bold()).foregroundStyle(darkGreen)
            Text(count).font(.title.bold())
            Text(line1).font(.caption).foregroundStyle(.secondary)
            Text(line2).font(.subheadline.bold()).foregroundStyle(darkGreen)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.green.opacity(0.18)))
    }

    private var personalSection: some View {
        VStack(spacing: 12) {
            labeledField("Name *", text: $name)
            Picker("Gender *", selection: $gender) {
                Text("Select").tag(Gender?.none)
                ForEach(Gender.allCases) { item in Text(item.rawValue).tag(Gender?.some(item)) }
            }.pickerStyle(.segmented)
            DatePicker("Date of Birth *", selection: $dob, in: ...eapDate, displayedComponents: .date)
            HStack {
                Text("Age (Auto)")
                Spacer()
                Text(String(calculatedAge)).bold()
            }
            labeledField("Father / Husband / Mother Name *", text: $guardian)
        }
    }

    private var locationSection: some View {
        VStack(spacing: 12) {
            labeledField("Address *", text: $address)
            labeledField("Panchayat *", text: $panchayat)
            HStack {
                Text("City / Taluk")
                Spacer()
                Text(selectedLocation?.place ?? "Auto").foregroundStyle(.secondary)
            }
            labeledField("PIN Code *", text: $pinCode, keyboard: .numberPad)
                .onChange(of: pinCode) { _, value in pinCode = digits(value, max: 6) }
            HStack { Text("State"); Spacer(); Text("Karnataka").foregroundStyle(.secondary) }
        }
    }

    private var contactSection: some View {
        VStack(spacing: 12) {
            labeledField("Mobile Number *", text: $mobile, keyboard: .phonePad)
                .onChange(of: mobile) { _, value in mobile = digits(value, max: 10) }
            labeledField("Alternate Mobile Number", text: $alternateMobile, keyboard: .phonePad)
                .onChange(of: alternateMobile) { _, value in alternateMobile = digits(value, max: 10) }
            labeledField("Email ID", text: $email, keyboard: .emailAddress)
            labeledField("Aadhaar No. (12 digits)", text: $aadhaar, keyboard: .numberPad)
                .onChange(of: aadhaar) { _, value in aadhaar = digits(value, max: 12) }
        }
    }

    private var educationSection: some View {
        VStack(spacing: 12) {
            labeledField("Highest Educational Qualification *", text: $education)
            labeledField("Occupation *", text: $occupation)
            labeledField("Individual Income", text: $income, keyboard: .numberPad)
            Picker("Category *", selection: $category) {
                Text("Select").tag(Category?.none)
                ForEach(Category.allCases) { item in Text(item.rawValue).tag(Category?.some(item)) }
            }.pickerStyle(.menu)
        }
    }

    private var eapSection: some View {
        VStack(spacing: 12) {
            Picker("Intention *", selection: $intention) {
                Text("Select").tag(Intention?.none)
                ForEach(Intention.allCases) { item in Text(item.rawValue).tag(Intention?.some(item)) }
            }.pickerStyle(.menu)
            Picker("Business Sector *", selection: $sector) {
                Text("Select").tag(BusinessSector?.none)
                ForEach(BusinessSector.allCases) { item in Text(item.rawValue).tag(BusinessSector?.some(item)) }
            }.pickerStyle(.menu)
            Picker("Do you want to attend MSDP? *", selection: $msdpInterest) {
                Text("Select").tag(Bool?.none)
                Text("Yes").tag(Bool?.some(true))
                Text("No").tag(Bool?.some(false))
            }.pickerStyle(.segmented)
        }
    }

    private var documentsSection: some View {
        VStack(spacing: 18) {
            photoBlock(title: "Candidate Photo *", image: candidatePhoto,
                       camera: { requestCamera { showCandidateCamera = true } },
                       upload: { showCandidateLibrary = true })
            Divider()
            photoBlock(title: "Applicant Signature Photo *", image: signaturePhoto,
                       camera: { requestCamera { showSignatureCamera = true } },
                       upload: { showSignatureLibrary = true })
        }
    }

    private func photoBlock(title: String, image: UIImage?, camera: @escaping () -> Void, upload: @escaping () -> Void) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.subheadline.bold())
            ZStack {
                RoundedRectangle(cornerRadius: 14).fill(Color(.secondarySystemBackground))
                if let image {
                    Image(uiImage: image).resizable().scaledToFit().padding(4)
                } else {
                    VStack(spacing: 6) {
                        Image(systemName: "photo").font(.title)
                        Text("No image selected").font(.caption).foregroundStyle(.secondary)
                    }
                }
            }.frame(height: title.contains("Signature") ? 140 : 190)
            HStack {
                Button(action: camera) { Label("Take Photo", systemImage: "camera.fill") }
                    .buttonStyle(.borderedProminent).tint(green)
                Button(action: upload) { Label("Upload", systemImage: "photo.on.rectangle") }
                    .buttonStyle(.bordered).tint(green)
            }
        }
    }

    private var declarationSection: some View {
        Toggle(isOn: $declaration) {
            Text("I declare that the information provided by me is correct. I will be responsible for any discrepancy detected.")
                .font(.subheadline)
        }
        .tint(green)
        .padding(14)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private var submitButton: some View {
        Button {
            Task { await submit() }
        } label: {
            HStack {
                if isSubmitting { ProgressView().tint(.white) }
                Text(isSubmitting ? "Saving..." : "Submit Application").bold()
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
        }
        .buttonStyle(.borderedProminent)
        .tint(green)
        .disabled(isSubmitting)
    }

    private func labeledField(_ title: String, text: Binding<String>, keyboard: UIKeyboardType = .default) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.subheadline.bold())
            TextField("", text: text)
                .keyboardType(keyboard)
                .textInputAutocapitalization(keyboard == .emailAddress ? .never : .sentences)
                .padding(12)
                .background(Color(.secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }

    private var calculatedAge: Int {
        let cal = Calendar.current
        var age = cal.dateComponents([.year], from: dob, to: eapDate).year ?? 0
        if age < 0 { age = 0 }
        return age
    }

    private func requestCamera(open: @escaping () -> Void) {
        guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
            showCameraUnavailable = true
            return
        }
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: open()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                DispatchQueue.main.async {
                    if granted { open() } else { showCameraUnavailable = true }
                }
            }
        default:
            showCameraUnavailable = true
        }
    }

    private func submit() async {
        guard validate() else { return }
        guard let selectedLocation,
              let gender,
              let category,
              let intention,
              let sector,
              let msdpInterest,
              let candidatePhoto,
              let signaturePhoto else { return }

        isSubmitting = true
        defer { isSubmitting = false }

        let fullAddress = [address, panchayat, selectedLocation.place, selectedLocation.district, "Karnataka", "PIN \(pinCode)"]
            .filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
            .joined(separator: ", ")

        let payload = RegistrationPayload(
            clientRequestId: UUID().uuidString,
            locationCode: selectedLocation.code,
            eapDate: eapDate.eapString(),
            name: name.trimmingCharacters(in: .whitespacesAndNewlines),
            gender: gender.rawValue,
            dob: dob.eapString(),
            ageOnEapDate: String(calculatedAge),
            guardianName: guardian,
            village: address,
            panchayat: panchayat,
            city: selectedLocation.place,
            pinCode: pinCode,
            projectLocation: selectedLocation.display,
            place: selectedLocation.place,
            fullAddress: fullAddress,
            mobile: mobile,
            alternateMobile: alternateMobile,
            email: email,
            idNumber: aadhaar,
            education: education,
            occupation: occupation,
            individualIncome: income,
            category: category.rawValue,
            intention: intention.rawValue,
            sector: sector.rawValue,
            sectors: sector.rawValue,
            msdpInterest: msdpInterest ? "Yes" : "No",
            photoBase64: candidatePhoto.jpegBase64(),
            signatureBase64: signaturePhoto.jpegBase64()
        )

        store.add(payload)

        if sync.isOnline {
            await sync.syncAll(store: store)
            await sync.refreshStatus(location: selectedLocation)
        }

        if let saved = store.record(id: payload.clientRequestId), saved.status == .synced {
            resultMessage = "Application submitted successfully.\n\nApplication Serial: \(saved.payload.totalSerialNumber)\nLocation Serial: \(saved.payload.individualSerialNumber)"
        } else {
            resultMessage = "Application saved safely on this iPhone.\n\nIt will receive the central serial number and final PDF automatically when internet is available.\nPending on this phone: \(store.pendingCount)"
        }
        showResult = true
    }

    private func validate() -> Bool {
        var problems: [String] = []
        if selectedLocation == nil { problems.append("HAL Project Location") }
        if name.trimmingCharacters(in: .whitespaces).isEmpty { problems.append("Name") }
        if gender == nil { problems.append("Gender") }
        if guardian.trimmingCharacters(in: .whitespaces).isEmpty { problems.append("Guardian Name") }
        if address.trimmingCharacters(in: .whitespaces).isEmpty { problems.append("Address") }
        if panchayat.trimmingCharacters(in: .whitespaces).isEmpty { problems.append("Panchayat") }
        if pinCode.count != 6 { problems.append("6 digit PIN") }
        if mobile.count != 10 || !("6"..."9").contains(String(mobile.prefix(1))) { problems.append("valid Mobile") }
        if !alternateMobile.isEmpty && alternateMobile.count != 10 { problems.append("valid Alternate Mobile") }
        if !aadhaar.isEmpty && aadhaar.count != 12 { problems.append("12 digit Aadhaar") }
        if education.trimmingCharacters(in: .whitespaces).isEmpty { problems.append("Education") }
        if occupation.trimmingCharacters(in: .whitespaces).isEmpty { problems.append("Occupation") }
        if category == nil { problems.append("Category") }
        if intention == nil { problems.append("Intention") }
        if sector == nil { problems.append("Business Sector") }
        if msdpInterest == nil { problems.append("MSDP") }
        if candidatePhoto == nil { problems.append("Candidate Photo") }
        if signaturePhoto == nil { problems.append("Signature Photo") }
        if !declaration { problems.append("Declaration") }

        if !problems.isEmpty {
            resultMessage = "Please complete: " + problems.joined(separator: ", ")
            showResult = true
            return false
        }
        return true
    }

    private func resetApplicantFields() {
        name = ""
        gender = nil
        dob = Calendar.current.date(byAdding: .year, value: -18, to: Date()) ?? Date()
        guardian = ""
        address = ""
        panchayat = ""
        pinCode = ""
        mobile = ""
        alternateMobile = ""
        email = ""
        aadhaar = ""
        education = ""
        occupation = ""
        income = ""
        category = nil
        intention = nil
        sector = nil
        msdpInterest = nil
        candidatePhoto = nil
        signaturePhoto = nil
        declaration = false
    }

    private func digits(_ value: String, max: Int) -> String {
        String(value.filter(\.isNumber).prefix(max))
    }
}
