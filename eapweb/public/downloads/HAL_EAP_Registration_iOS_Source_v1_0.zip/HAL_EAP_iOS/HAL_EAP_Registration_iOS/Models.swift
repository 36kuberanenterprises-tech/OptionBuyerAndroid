import Foundation
import UIKit

struct ProjectLocation: Identifiable, Hashable, Codable {
    let id: String
    let district: String
    let place: String

    var display: String { "\(district) | \(place)" }
    var code: String { id }

    static let all: [ProjectLocation] = [
        .init(id: "K-M", district: "Kolar", place: "Mulbagal"),
        .init(id: "K-S", district: "Kolar", place: "Srinivaspur"),
        .init(id: "BR-D", district: "Bengaluru Rural", place: "Devanahalli"),
        .init(id: "BR-H", district: "Bengaluru Rural", place: "Hoskote"),
        .init(id: "T-T", district: "Tumkur", place: "Tumkur"),
        .init(id: "T-G", district: "Tumkur", place: "Gubbi"),
        .init(id: "T-S", district: "Tumkur", place: "Sira"),
        .init(id: "BS-R", district: "Bengaluru South", place: "Ramanagara"),
        .init(id: "BS-C", district: "Bengaluru South", place: "Channapatna")
    ]
}

enum Gender: String, CaseIterable, Codable, Identifiable {
    case male = "Male"
    case female = "Female"
    case other = "Other"
    var id: String { rawValue }
}

enum Category: String, CaseIterable, Codable, Identifiable {
    case gen = "GEN"
    case ews = "EWS"
    case sc = "SC"
    case st = "ST"
    case obc = "OBC"
    case minority = "MINORITY"
    var id: String { rawValue }
}

enum Intention: String, CaseIterable, Codable, Identifiable {
    case employment = "Employment"
    case selfEmployment = "Self Employment"
    var id: String { rawValue }
}

enum BusinessSector: String, CaseIterable, Codable, Identifiable {
    case fashion = "Fashion Technology"
    case food = "Food Processing"
    case jute = "Jute Bag Manufacturing"
    case beautician = "Beautician"
    var id: String { rawValue }
}

struct RegistrationPayload: Codable, Identifiable {
    var id: String { clientRequestId }

    var action: String = "submitRegistration"
    var clientRequestId: String
    var totalSerialNumber: String = ""
    var individualSerialNumber: String = ""
    var totalApplicationCount: Int = 0
    var locationApplicationCount: Int = 0
    var locationCode: String

    var eapDate: String
    var name: String
    var gender: String
    var dob: String
    var ageOnEapDate: String
    var guardianName: String

    var village: String // Backend compatibility: UI label is Address.
    var panchayat: String
    var block: String = ""
    var city: String
    var pinCode: String
    var state: String = "Karnataka"
    var projectLocation: String
    var place: String
    var fullAddress: String

    var mobile: String
    var alternateMobile: String
    var email: String
    var idType: String = "Aadhaar"
    var idNumber: String
    var education: String
    var occupation: String
    var individualIncome: String
    var category: String
    var intention: String
    var sector: String
    var sectors: String
    var msdpInterest: String

    var photoBase64: String
    var signatureType: String = "Photo"
    var signatureBase64: String
    var declarationAccepted: Bool = true

    var pdfFileName: String = ""
    var pdfBase64: String = ""
    var localPdfLocation: String = ""

    var pdfUrl: String = ""
    var photoUrl: String = ""
    var signatureUrl: String = ""
    var editableUrl: String = ""
    var folderUrl: String = ""
}

enum LocalSyncStatus: String, Codable {
    case pending = "PENDING"
    case syncing = "SYNCING"
    case synced = "SYNCED"
}

struct LocalRegistration: Codable, Identifiable {
    var id: String { payload.clientRequestId }
    var payload: RegistrationPayload
    var status: LocalSyncStatus
    var createdAt: Date
    var syncedAt: Date?
    var lastError: String?
}

struct CentralStatus: Codable {
    var totalApplicationCount: Int = 0
    var locationApplicationCount: Int = 0
    var nextTotalSerial: String = ""
    var nextLocationSerial: String = ""
}

struct APIResponse: Decodable {
    var success: Bool
    var message: String?
    var totalSerialNumber: String?
    var individualSerialNumber: String?
    var totalApplicationCount: Int?
    var locationApplicationCount: Int?
    var nextTotalSerial: String?
    var nextLocationSerial: String?
    var pdfUrl: String?
    var photoUrl: String?
    var signatureUrl: String?
    var editableUrl: String?
    var folderUrl: String?
    var pdfFileName: String?
}

extension Date {
    func eapString() -> String {
        let f = DateFormatter()
        f.dateFormat = "dd/MM/yyyy"
        f.locale = Locale(identifier: "en_IN")
        return f.string(from: self)
    }
}

extension UIImage {
    func resized(maxDimension: CGFloat = 1400) -> UIImage {
        let largest = max(size.width, size.height)
        guard largest > maxDimension else { return self }
        let scale = maxDimension / largest
        let newSize = CGSize(width: size.width * scale, height: size.height * scale)
        let renderer = UIGraphicsImageRenderer(size: newSize)
        return renderer.image { _ in
            self.draw(in: CGRect(origin: .zero, size: newSize))
        }
    }

    func jpegBase64(quality: CGFloat = 0.72) -> String {
        resized().jpegData(compressionQuality: quality)?.base64EncodedString() ?? ""
    }
}
