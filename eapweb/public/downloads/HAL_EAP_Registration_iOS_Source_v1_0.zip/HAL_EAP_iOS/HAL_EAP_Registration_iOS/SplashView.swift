import SwiftUI

struct SplashView: View {
    @State private var logoScale: CGFloat = 0.72
    @State private var logoOpacity = 0.0
    @State private var titleOpacity = 0.0
    @State private var partnerOpacity = 0.0

    var body: some View {
        VStack(spacing: 18) {
            Spacer()
            Image("EDII")
                .resizable()
                .scaledToFit()
                .frame(width: 180, height: 180)
                .scaleEffect(logoScale)
                .opacity(logoOpacity)

            Text("HAL EAP Registration")
                .font(.title.bold())
                .opacity(titleOpacity)

            Text("Entrepreneurship Awareness Programme")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .opacity(titleOpacity)

            RoundedRectangle(cornerRadius: 18)
                .fill(Color.green.opacity(0.06))
                .frame(height: 120)
                .overlay {
                    HStack(spacing: 18) {
                        VStack(spacing: 4) {
                            Image("EDII").resizable().scaledToFit().frame(height: 58)
                            Text("Organised by EDII").font(.caption.bold())
                        }
                        Divider().frame(height: 80)
                        VStack(spacing: 4) {
                            Image("HAL").resizable().scaledToFit().frame(height: 58)
                            Text("Sponsored by HAL").font(.caption.bold())
                        }
                    }.padding()
                }
                .padding(.horizontal, 24)
                .opacity(partnerOpacity)

            Text("Designed and Developed by Ajay Rao\nEDII SRO Bengaluru")
                .font(.caption.bold())
                .foregroundStyle(.green)
                .multilineTextAlignment(.center)
                .opacity(partnerOpacity)
            Spacer()
        }
        .background(Color.white.ignoresSafeArea())
        .onAppear {
            withAnimation(.spring(response: 0.65, dampingFraction: 0.72)) {
                logoScale = 1
                logoOpacity = 1
            }
            withAnimation(.easeOut(duration: 0.45).delay(0.45)) { titleOpacity = 1 }
            withAnimation(.easeOut(duration: 0.50).delay(0.85)) { partnerOpacity = 1 }
        }
    }
}
