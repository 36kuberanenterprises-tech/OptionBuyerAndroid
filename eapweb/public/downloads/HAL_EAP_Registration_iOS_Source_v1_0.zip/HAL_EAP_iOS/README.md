# HAL EAP Registration for iOS

Native SwiftUI iPhone/iPad version of the HAL EAP Registration field app.

## Central data

This project is already configured to use the same Apps Script Web App and the same EAP_Master Sheet used by the Android app. Android and iOS therefore share one central numbering and one data source.

## Included workflow

- EAP Date and HAL Project Location
- Candidate details and auto age calculation
- Address, Panchayat, City/Taluk, PIN and Karnataka state
- Mobile, alternate mobile, email and Aadhaar validation
- Education, occupation, income and category
- Employment / Self Employment intention
- Single business sector selection
- MSDP interest
- Candidate photo from camera or photo library
- Signature photo from camera or photo library
- Declaration and submit
- Multiple-record offline queue
- Automatic central serial reservation during sync
- Central total serial and location serial
- Final PDF generation from the official EAP template
- PDF naming: Applicant_Location_LocationSerial.pdf
- Sync to the same EAP_Master Sheet and central Drive folders
- Applications history with Pending / Synced status
- PDF, editable record and Drive folder links after sync
- EDII / HAL branded splash screen
- Designed and Developed by Ajay Rao, EDII SRO Bengaluru

## iOS requirement

Minimum deployment target is iOS 16.0.

## Open and run

1. Copy this project to a Mac with Xcode.
2. Open `HAL_EAP_Registration_iOS.xcodeproj`.
3. Select the `HAL_EAP_Registration_iOS` target.
4. Open **Signing & Capabilities**.
5. Select your Apple Developer Team.
6. If required, change the Bundle Identifier from `com.edii.eapregistration.ios` to an identifier registered under your Apple Developer account.
7. Connect an iPhone and press Run, or use an iPhone simulator for UI testing.

## Distribution

To install on multiple field iPhones, use TestFlight or an approved Apple distribution method. Creating a signed IPA requires macOS, Xcode and an Apple Developer signing identity. The source project itself does not contain private Apple signing certificates.

## Security note

The current field build uses the same backend token as the Android app. For wider public distribution, rotate the token and consider stronger per-user authentication before publishing to the public App Store.
