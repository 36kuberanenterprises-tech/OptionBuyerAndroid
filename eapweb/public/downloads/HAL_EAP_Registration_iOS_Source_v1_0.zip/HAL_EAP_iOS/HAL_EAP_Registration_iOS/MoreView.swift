import SwiftUI

struct MoreView: View {
    @EnvironmentObject var store: OfflineStore
    @EnvironmentObject var sync: SyncService

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    card("Central EAP Master Sync") {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("Connected to EAP_Master Sheet", systemImage: "checkmark.circle.fill")
                                .foregroundStyle(.green).font(.headline)
                            Text(sync.isOnline ? "Internet: Available" : "Internet: Offline")
                            Text("Pending on this iPhone: \(store.pendingCount)")
                            Text("Synced records: \(store.syncedCount)")
                            Button {
                                Task { await sync.syncAll(store: store) }
                            } label: {
                                HStack {
                                    if sync.isSyncing { ProgressView().tint(.white) }
                                    Text(sync.isSyncing ? "Syncing..." : "Sync Now").bold()
                                }
                                .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.green)
                            .disabled(!sync.isOnline || sync.isSyncing)
                            if !sync.lastMessage.isEmpty {
                                Text(sync.lastMessage).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }

                    card("How data is stored") {
                        VStack(alignment: .leading, spacing: 8) {
                            bullet("All iPhone and Android records use the same central EAP_Master Sheet.")
                            bullet("Offline registrations stay safely on the phone until internet returns.")
                            bullet("Central serial numbers are assigned by the common backend to avoid duplicates.")
                            bullet("Candidate photo, signature and final PDF are stored in central Google Drive folders.")
                        }
                    }

                    card("App Information") {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("HAL EAP Registration for iOS").font(.headline)
                            Text("Version 1.0")
                            Text("Minimum supported iOS: 16.0")
                            Text("Central data destination: EAP_Master Sheet only")
                            Divider()
                            Text("Designed and Developed by Ajay Rao")
                                .font(.subheadline.bold()).foregroundStyle(.green)
                            Text("EDII SRO Bengaluru").font(.caption)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("More")
        }
    }

    private func card<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title).font(.headline).foregroundStyle(.green)
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.green.opacity(0.15)))
    }

    private func bullet(_ text: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Text("•").bold()
            Text(text).font(.subheadline)
        }
    }
}
