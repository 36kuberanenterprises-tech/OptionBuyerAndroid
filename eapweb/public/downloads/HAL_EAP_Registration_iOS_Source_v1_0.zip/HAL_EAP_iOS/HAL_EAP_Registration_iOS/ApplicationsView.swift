import SwiftUI

struct ApplicationsView: View {
    @EnvironmentObject var store: OfflineStore
    @EnvironmentObject var sync: SyncService
    @State private var search = ""
    @State private var filter: Filter = .all

    enum Filter: String, CaseIterable, Identifiable {
        case all = "All"
        case today = "Today"
        case pending = "Pending"
        var id: String { rawValue }
    }

    private var filtered: [LocalRegistration] {
        store.records
            .filter { record in
                switch filter {
                case .all: return true
                case .today: return Calendar.current.isDateInToday(record.createdAt)
                case .pending: return record.status != .synced
                }
            }
            .filter { record in
                guard !search.isEmpty else { return true }
                let p = record.payload
                let haystack = [p.name, p.mobile, p.totalSerialNumber, p.individualSerialNumber, p.projectLocation]
                    .joined(separator: " ").lowercased()
                return haystack.contains(search.lowercased())
            }
            .sorted { $0.createdAt > $1.createdAt }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                HStack {
                    VStack(alignment: .leading) {
                        Text("Applications").font(.title2.bold())
                        Text("Total \(store.records.count) • Pending \(store.pendingCount)")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button {
                        Task { await sync.syncAll(store: store) }
                    } label: {
                        if sync.isSyncing { ProgressView() }
                        else { Image(systemName: "arrow.triangle.2.circlepath") }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                }
                .padding(.horizontal)

                TextField("Search by name, mobile or serial", text: $search)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                Picker("Filter", selection: $filter) {
                    ForEach(Filter.allCases) { item in Text(item.rawValue).tag(item) }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)

                if filtered.isEmpty {
                    Spacer()
                    ContentUnavailableView(
                        "No applications",
                        systemImage: "doc.text.magnifyingglass",
                        description: Text(filter == .pending ? "No pending records on this iPhone." : "Applications will appear here after registration.")
                    )
                    Spacer()
                } else {
                    List(filtered) { record in
                        ApplicationRow(record: record)
                    }
                    .listStyle(.plain)
                }
            }
            .navigationBarHidden(true)
        }
    }
}

private struct ApplicationRow: View {
    let record: LocalRegistration

    private var statusText: String {
        switch record.status {
        case .synced: return "Synced"
        case .syncing: return "Syncing"
        case .pending: return "Pending Sync"
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(record.payload.name).font(.headline)
                Spacer()
                Text(statusText)
                    .font(.caption.bold())
                    .foregroundStyle(record.status == .synced ? .green : .orange)
                    .padding(.horizontal, 8).padding(.vertical, 4)
                    .background((record.status == .synced ? Color.green : Color.orange).opacity(0.10), in: Capsule())
            }
            Text(record.payload.totalSerialNumber.isEmpty ? "Pending central serial" : record.payload.totalSerialNumber)
                .font(.subheadline.bold())
            if !record.payload.individualSerialNumber.isEmpty {
                Text(record.payload.individualSerialNumber).font(.caption)
            }
            Text(record.payload.projectLocation).font(.caption).foregroundStyle(.secondary)
            Text(record.createdAt.formatted(date: .abbreviated, time: .shortened))
                .font(.caption2).foregroundStyle(.secondary)

            if let error = record.lastError, !error.isEmpty, record.status != .synced {
                Text(error).font(.caption2).foregroundStyle(.red)
            }

            if record.status == .synced {
                HStack(spacing: 12) {
                    if let url = URL(string: record.payload.pdfUrl), !record.payload.pdfUrl.isEmpty {
                        Link("PDF", destination: url)
                    }
                    if let url = URL(string: record.payload.editableUrl), !record.payload.editableUrl.isEmpty {
                        Link("Edit", destination: url)
                    }
                    if let url = URL(string: record.payload.folderUrl), !record.payload.folderUrl.isEmpty {
                        Link("Folder", destination: url)
                    }
                }
                .font(.caption.bold())
            }
        }
        .padding(.vertical, 6)
    }
}
