import Foundation
import UIKit

struct GeneratedPDF {
    let data: Data
    let url: URL
    let fileName: String
}

enum PDFGenerator {
    static func generate(payload: RegistrationPayload) throws -> GeneratedPDF {
        let cleanName = safe(payload.name)
        let cleanPlace = safe(payload.place)
        let serial = safe(payload.individualSerialNumber.replacingOccurrences(of: "/", with: "-"))
        let fileName = "\(cleanName)_\(cleanPlace)_\(serial.isEmpty ? UUID().uuidString : serial).pdf"

        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dir = docs.appendingPathComponent("EAP Registrations", isDirectory: true)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent(fileName)

        let pageRect = CGRect(x: 0, y: 0, width: 595, height: 842)
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)
        let data = renderer.pdfData { context in
            context.beginPage()

            if let template = UIImage(named: "EAPTemplate") {
                template.draw(in: pageRect)
            } else {
                UIColor.white.setFill()
                context.cgContext.fill(pageRect)
            }

            let normal = UIFont.systemFont(ofSize: 8.5)
            let bold = UIFont.boldSystemFont(ofSize: 8.5)
            let small = UIFont.systemFont(ofSize: 7.5)

            draw(payload.eapDate, at: CGPoint(x: 420, y: 175), font: normal)
            draw(payload.place, at: CGPoint(x: 420, y: 193), font: normal)

            draw(payload.name, at: CGPoint(x: 145, y: 234), font: bold)
            draw(payload.gender, at: CGPoint(x: 145, y: 254), font: normal)
            draw(payload.dob, at: CGPoint(x: 145, y: 273), font: normal)
            draw(payload.ageOnEapDate, at: CGPoint(x: 410, y: 273), font: normal)
            draw(payload.guardianName, at: CGPoint(x: 190, y: 293), font: normal)

            draw(payload.fullAddress, in: CGRect(x: 145, y: 309, width: 310, height: 38), font: small)
            draw(payload.mobile, at: CGPoint(x: 145, y: 355), font: normal)
            draw(payload.alternateMobile, at: CGPoint(x: 405, y: 355), font: normal)
            draw(payload.email, at: CGPoint(x: 145, y: 375), font: normal)

            draw(payload.idNumber, at: CGPoint(x: 145, y: 395), font: normal)
            draw(payload.education, at: CGPoint(x: 190, y: 415), font: normal)
            draw(payload.occupation, at: CGPoint(x: 145, y: 435), font: normal)
            draw(payload.individualIncome, at: CGPoint(x: 405, y: 435), font: normal)
            draw(payload.category, at: CGPoint(x: 145, y: 455), font: normal)
            draw(payload.intention, at: CGPoint(x: 205, y: 477), font: normal)
            draw(payload.sector, at: CGPoint(x: 180, y: 507), font: normal)
            draw(payload.msdpInterest, at: CGPoint(x: 255, y: 533), font: normal)

            if let photo = imageFromBase64(payload.photoBase64) {
                photo.draw(in: aspectFit(photo.size, inside: CGRect(x: 462, y: 218, width: 85, height: 105)))
            }
            if let signature = imageFromBase64(payload.signatureBase64) {
                signature.draw(in: aspectFit(signature.size, inside: CGRect(x: 390, y: 676, width: 140, height: 55)))
            }

            draw(payload.totalSerialNumber, at: CGPoint(x: 66, y: 785), font: UIFont.boldSystemFont(ofSize: 8))
            draw(payload.individualSerialNumber, at: CGPoint(x: 350, y: 785), font: UIFont.boldSystemFont(ofSize: 8))
        }

        try data.write(to: url, options: [.atomic])
        return GeneratedPDF(data: data, url: url, fileName: fileName)
    }

    private static func draw(_ text: String, at point: CGPoint, font: UIFont) {
        let attrs: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: UIColor.black
        ]
        NSString(string: text).draw(at: point, withAttributes: attrs)
    }

    private static func draw(_ text: String, in rect: CGRect, font: UIFont) {
        let style = NSMutableParagraphStyle()
        style.lineBreakMode = .byWordWrapping
        let attrs: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: UIColor.black,
            .paragraphStyle: style
        ]
        NSString(string: text).draw(in: rect, withAttributes: attrs)
    }

    private static func imageFromBase64(_ value: String) -> UIImage? {
        let clean = value.replacingOccurrences(of: "data:image/jpeg;base64,", with: "")
        guard let data = Data(base64Encoded: clean) else { return nil }
        return UIImage(data: data)
    }

    private static func aspectFit(_ size: CGSize, inside rect: CGRect) -> CGRect {
        guard size.width > 0, size.height > 0 else { return rect }
        let scale = min(rect.width / size.width, rect.height / size.height)
        let w = size.width * scale
        let h = size.height * scale
        return CGRect(x: rect.midX - w / 2, y: rect.midY - h / 2, width: w, height: h)
    }

    private static func safe(_ value: String) -> String {
        let invalid = CharacterSet(charactersIn: "\\/:*?\"<>|#%")
        let pieces = value.trimmingCharacters(in: .whitespacesAndNewlines)
            .components(separatedBy: invalid)
        return pieces.joined(separator: "_")
            .replacingOccurrences(of: " ", with: "_")
            .replacingOccurrences(of: "__", with: "_")
    }
}
