import Foundation

@MainActor
final class OfflineStore: ObservableObject {
    @Published private(set) var records: [LocalRegistration] = []

    private let fileURL: URL
    private let encoder: JSONEncoder
    private let decoder: JSONDecoder

    init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let dir = base.appendingPathComponent("HAL_EAP_Registration", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        fileURL = dir.appendingPathComponent("offline_queue.json")

        encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601

        load()
    }

    var pendingCount: Int {
        records.filter { $0.status != .synced }.count
    }

    var syncedCount: Int {
        records.filter { $0.status == .synced }.count
    }

    func add(_ payload: RegistrationPayload) {
        let record = LocalRegistration(
            payload: payload,
            status: .pending,
            createdAt: Date(),
            syncedAt: nil,
            lastError: nil
        )
        records.append(record)
        save()
    }

    func update(_ record: LocalRegistration) {
        guard let idx = records.firstIndex(where: { $0.id == record.id }) else { return }
        records[idx] = record
        save()
    }

    func record(id: String) -> LocalRegistration? {
        records.first(where: { $0.id == id })
    }

    func pendingRecords() -> [LocalRegistration] {
        records
            .filter { $0.status != .synced }
            .sorted { $0.createdAt < $1.createdAt }
    }

    func clearSynced() {
        records.removeAll { $0.status == .synced }
        save()
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL) else { return }
        records = (try? decoder.decode([LocalRegistration].self, from: data)) ?? []
    }

    private func save() {
        guard let data = try? encoder.encode(records) else { return }
        try? data.write(to: fileURL, options: [.atomic])
    }
}
